var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");



}
/*
     FILE ARCHIVED ON 11:31:23 Apr 11, 2020 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:37:48 Sep 29, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  exclusion.robots: 0.193
  load_resource: 186.607
  captures_list: 160.555
  esindex: 0.011
  LoadShardBlock: 137.479 (3)
  exclusion.robots.policy: 0.18
  PetaboxLoader3.resolve: 184.275 (3)
  RedisCDXSource: 3.239
  CDXLines.iter: 16.774 (3)
  PetaboxLoader3.datanode: 94.892 (4)
*/