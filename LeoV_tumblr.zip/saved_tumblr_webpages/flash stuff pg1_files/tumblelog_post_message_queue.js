var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

/*! scripts/tumblelog_post_message_queue.js */
!function(e){"use strict";e.postMessageQueue||(e.postMessageQueue=[],e.postMessageCallback=function(s){e.postMessageQueue.push(s.data)},window.addEventListener?window.addEventListener("message",e.postMessageCallback):window.attachEvent("onmessage",e.postMessageCallback))}(window.Tumblr||(window.Tumblr={}));

}
/*
     FILE ARCHIVED ON 16:31:29 Apr 13, 2019 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:37:39 Sep 29, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  exclusion.robots: 0.125
  load_resource: 1332.573 (2)
  PetaboxLoader3.datanode: 1797.035 (8)
  esindex: 0.01
  LoadShardBlock: 1249.834 (6)
  PetaboxLoader3.resolve: 330.168 (3)
  RedisCDXSource: 1.807
  CDXLines.iter: 259.797 (3)
  exclusion.robots.policy: 0.114
*/