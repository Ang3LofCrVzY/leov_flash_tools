var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

/*! scripts/tumblelog_post_message_queue.js */
!function(e){"use strict";e.postMessageQueue||(e.postMessageQueue=[],e.postMessageCallback=function(s){e.postMessageQueue.push(s.data)},window.addEventListener?window.addEventListener("message",e.postMessageCallback):window.attachEvent("onmessage",e.postMessageCallback))}(window.Tumblr||(window.Tumblr={}));

}
/*
     FILE ARCHIVED ON 11:33:31 Aug 21, 2018 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 03:17:54 Sep 29, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  CDXLines.iter: 218.545 (3)
  PetaboxLoader3.resolve: 128.091 (2)
  load_resource: 213.081 (2)
  exclusion.robots.policy: 0.216
  esindex: 0.015
  PetaboxLoader3.datanode: 326.415 (8)
  RedisCDXSource: 8.966
  exclusion.robots: 0.235
  LoadShardBlock: 291.941 (6)
*/